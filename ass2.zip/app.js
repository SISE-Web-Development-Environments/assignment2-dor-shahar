
var context;
var shape = new Object();
var board;
var score;
var pac_color;
var start_time;
var time_elapsed;
var interval;
/* keys for move */
var moveKeys = {
	"upButton": 38,
	"downButton": 40,
	"leftButton": 37,
	"rightButton": 39
};
var tmpMoveKeys = {
	"upButton": 38,
	"downButton": 40,
	"leftButton": 37,
	"rightButton": 39
};
var invalidMoveKeys = [
	20, 19, 27, 45, 46,
	91, 93, 144, 112, 113,
	114, 115, 116, 117, 118,
	119, 120, 121, 122, 123
]
var foodBallsNumber = 50;
var mostersNum = 4;
var ballsColors = {
	"smallBallsColor": "#6666ff",
	"mediumBallsColor": "#9933ff",
	"bigBallsColor": "#ff33cc"
}
var pressedKey;
var isButtonPressed = {
	"upButton": false,
	"downButton": false,
	"leftButton": false,
	"rightButton": false
};
var buttonClickedColor = "#ff3333";
var buttonDefaultColor = "#1a8cff";
var gameTime = 60;
const CSS_COLOR_NAMES = ['#FF6633', '#FFB399', '#FF33FF', '#FFFF99', '#00B3E6',
	'#E6B333', '#3366E6', '#999966', '#99FF99', '#B34D4D',
	'#80B300', '#809900', '#E6B3B3', '#6680B3', '#66991A',
	'#FF99E6', '#CCFF1A', '#FF1A66', '#E6331A', '#33FFCC',
	'#66994D', '#B366CC', '#4D8000', '#B33300', '#CC80CC',
	'#66664D', '#991AFF', '#E666FF', '#4DB3FF', '#1AB399',
	'#E666B3', '#33991A', '#CC9999', '#B3B31A', '#00E680',
	'#4D8066', '#809980', '#E6FF80', '#1AFF33', '#999933',
	'#FF3380', '#CCCC00', '#66E64D', '#4D80CC', '#9900B3',
	'#E64D66', '#4DB380', '#FF4D4D', '#99E6E6', '#6666FF'];

var users;


$(document).ready(function () {
	context = canvas.getContext("2d");
	resetUsersDictionary();
	createDivsDictionary();
	dateOptionReset();
	resetMoveKeysButtons();
	addEvents();
});

function addEvents() {
	$("#welcomeToRegisterButton").click(goToRegisterPage);
	$("#welcomeToLoginButton").click(goToLoginPage);
	$("#loginToRegisterBtn").click(goToRegisterPage);
	$("#registerForm").on("submit", register);
	$("#loginForm").on("submit", login);

	// $("#aboutMenu").click()

	$("#settingMenu").click(goToSettings)
	$("#loginMenu").click(goToLoginPage)
	$("#registerMenu").click(goToRegisterPage)
	$("#welcomeMenu").click(goToWelcomePage)

	$("#ballsNum").mouseup(setSliderValue.bind(context, "#lblBalssNum", "Number Of Balls: ", $("#ballsNum")[0]));
	$("#monstersNum").mouseup(setSliderValue.bind(context, "#lblmonstersNum", "Number Of Monsters: ", $("#monstersNum")[0]));
	$("#startGameButton").click(submit);
	$("#randomSettingButton").click(setRandomSetting);
	$("#upButton").click(pressedSetKeyButton.bind($("#upButton")[0]));
	$("#downButton").click(pressedSetKeyButton.bind($("#downButton")[0]));
	$("#leftButton").click(pressedSetKeyButton.bind($("#leftButton")[0]));
	$("#rightButton").click(pressedSetKeyButton.bind($("#rightButton")[0]));
}

function Start() {
	board = new Array();
	score = 0;
	pac_color = "yellow";
	var cnt = 100;
	var food_remain = 50;
	var pacman_remain = 1;
	start_time = new Date();
	for (var i = 0; i < 10; i++) {
		board[i] = new Array();
		//put obstacles in (i=3,j=3) and (i=3,j=4) and (i=3,j=5), (i=6,j=1) and (i=6,j=2)
		for (var j = 0; j < 10; j++) {
			if (
				(i == 3 && j == 3) ||
				(i == 3 && j == 4) ||
				(i == 3 && j == 5) ||
				(i == 6 && j == 1) ||
				(i == 6 && j == 2)
			) {
				board[i][j] = 4;
			} else {
				var randomNum = Math.random();
				if (randomNum <= (1.0 * food_remain) / cnt) {
					food_remain--;
					board[i][j] = 1;
				} else if (randomNum < (1.0 * (pacman_remain + food_remain)) / cnt) {
					shape.i = i;
					shape.j = j;
					pacman_remain--;
					board[i][j] = 2;
				} else {
					board[i][j] = 0;
				}
				cnt--;
			}
		}
	}
	while (food_remain > 0) {
		var emptyCell = findRandomEmptyCell(board);
		board[emptyCell[0]][emptyCell[1]] = 1;
		food_remain--;
	}
	keysDown = {};
	addEventListener(
		"keydown",
		function (e) {
			keyPress(e);
		},
		false
	);
	addEventListener(
		"keyup",
		function (e) {
			keyRelease(e);
		},
		false
	);
	interval = setInterval(UpdatePosition, 250);
}

function findRandomEmptyCell(board) {
	var i = Math.floor(Math.random() * 9 + 1);
	var j = Math.floor(Math.random() * 9 + 1);
	while (board[i][j] != 0) {
		i = Math.floor(Math.random() * 9 + 1);
		j = Math.floor(Math.random() * 9 + 1);
	}
	return [i, j];
}

function GetKeyPressed() {
	if (keysDown[this.moveKeys["upButton"]]) {
		return 1;
	}
	if (keysDown[this.moveKeys["downButton"]]) {
		return 2;
	}
	if (keysDown[this.moveKeys["leftButton"]]) {
		return 3;
	}
	if (keysDown[this.moveKeys["rightButton"]]) {
		return 4;
	}
}

function Draw() {
	canvas.width = canvas.width; //clean board
	lblScore.value = score;
	lblTime.value = time_elapsed;
	for (var i = 0; i < 10; i++) {
		for (var j = 0; j < 10; j++) {
			var center = new Object();
			center.x = i * 60 + 30;
			center.y = j * 60 + 30;
			if (board[i][j] == 2) {
				context.beginPath();
				context.arc(center.x, center.y, 30, 0.15 * Math.PI, 1.85 * Math.PI); // half circle
				context.lineTo(center.x, center.y);
				context.fillStyle = pac_color; //color
				context.fill();
				context.beginPath();
				context.arc(center.x + 5, center.y - 15, 5, 0, 2 * Math.PI); // circle
				context.fillStyle = "black"; //color
				context.fill();
			} else if (board[i][j] == 1) {
				context.beginPath();
				context.arc(center.x, center.y, 15, 0, 2 * Math.PI); // circle
				context.fillStyle = "blue"; //color
				context.fill();
			} else if (board[i][j] == 4) {
				context.beginPath();
				context.rect(center.x - 30, center.y - 30, 60, 60);
				context.fillStyle = "black"; //color
				context.fill();
			}
		}
	}
}

function UpdatePosition() {
	board[shape.i][shape.j] = 0;
	var x = GetKeyPressed();
	if (x == 1) {
		if (shape.j > 0 && board[shape.i][shape.j - 1] != 4) {
			shape.j--;
		}
	}
	if (x == 2) {
		if (shape.j < 9 && board[shape.i][shape.j + 1] != 4) {
			shape.j++;
		}
	}
	if (x == 3) {
		if (shape.i > 0 && board[shape.i - 1][shape.j] != 4) {
			shape.i--;
		}
	}
	if (x == 4) {
		if (shape.i < 9 && board[shape.i + 1][shape.j] != 4) {
			shape.i++;
		}
	}
	if (board[shape.i][shape.j] == 1) {
		score++;
	}
	board[shape.i][shape.j] = 2;
	var currentTime = new Date();
	time_elapsed = window.gameTime - ((currentTime - start_time) / 1000);
	if (score >= 20 && time_elapsed <= 10) {
		pac_color = "green";
	}
	if (time_elapsed <= 0) {
		window.clearInterval(interval);
		// window.alert("Game completed");
	} else {
		Draw();
	}
}

function submit() {
	if (settingInputCheck()) {
		window.goToGame();
		window.assignMoveKeys();
		window.Start();
	}
}

function settingInputCheck() {

	var inputs = $(".textBoxInput");

	// checks for balls colors
	for (let i = 0; i < inputs.length - 1; i++) {
		this.ballsColors[inputs[i].id] = inputs[i].value;

	}
	// check for a valid game time
	let gameTimeInput = parseInt(inputs[inputs.length - 1].value)
	if (gameTimeInput >= 60) {
		this.gameTime = gameTimeInput;
	} else if (inputs[inputs.length - 1].value != "") {
		let elemName = inputs[inputs.length - 1].labels[0].firstChild.data
		this.invalidInputAlert(elemName.substring(0, elemName.length - 1), "Time");
		return false;
	}
	this.foodBallsNumber = parseInt(inputs[0].value)
	this.mostersNum = parseInt(inputs[inputs.length - 1].value)
	return true;
}

function setRandomSetting() {

	window.tmpMoveKeys["upButton"] = 38;
	window.tmpMoveKeys["rightButton"] = 39;
	window.tmpMoveKeys["downButton"] = 40;
	window.tmpMoveKeys["leftButton"] = 37;

	// sets random number of balls
	$("#ballsNum")[0].value = 50 + Math.floor(Math.random() * 41);
	setSliderValue("#lblBalssNum", "Number Of Balls: ", $("#ballsNum")[0]);
	// sets random number of monsters
	$("#monstersNum")[0].value = 1 + Math.floor(Math.random() * 4);
	setSliderValue("#lblmonstersNum", "Number Of Monsters: ", $("#monstersNum")[0]);

	$("#setTimer")[0].value = 60 + Math.floor(Math.random() * 241);

	let colorsIndex = new Set();
	while (colorsIndex.size < 3) {
		let randomIndex = Math.floor(Math.random() * CSS_COLOR_NAMES.length);
		if (!colorsIndex.has(randomIndex))
			colorsIndex.add(randomIndex);
	}
	const it = colorsIndex.values();
	$("#smallBallsColor")[0].value = CSS_COLOR_NAMES[it.next().value].toLowerCase();
	$("#mediumBallsColor")[0].value = CSS_COLOR_NAMES[it.next().value].toLowerCase();
	$("#bigBallsColor")[0].value = CSS_COLOR_NAMES[it.next().value].toLowerCase();
}

function invalidInputAlert(elementName, type) {
	let alert = "";
	if (type == "Color")
		alert = "Color Input at '" + elementName + "' TextBox is Invalid\nPlease Try Again...";
	else if (type == "Time")
		alert = "Time Setup at '" + elementName + "' TextBox is Invalid\nThe setup time should be a number greater then 60.\nPlease Try Again...";
	window.alert(alert)
}

function isColor(strColor) {
	var s = new Option().style;
	s.color = strColor;
	return s.color == strColor;
}

function setSliderValue(eleID, str, element) {
	$(eleID)[0].innerText = str + element.value;
}

function pressedSetKeyButton(button) {
	if (isAButtonPressed())
		return;
	isButtonPressed[button.target.id] = true;
	button.target.style.backgroundColor = window.buttonClickedColor;
	button.target.innerText = "Press\nKey!"
}

function setupButtton(key, pressedID) {
	this.tmpMoveKeys[pressedID] = key;
	isButtonPressed[pressedID] = false;
}

function keyPress(e) {
	if (isAButtonPressed()) {
		return;
	} else {
		keysDown[e.keyCode] = true;
	}
}

function keyRelease(e) {
	if (isAButtonPressed()) {
		if (window.invalidMoveKeys.includes(e.keyCode)) {
			window.alert("You can't use this key foe playing.\nPlease Choose another...")
			return;
		}
		if (Object.values(window.tmpMoveKeys).includes(e.keyCode) &&
			this.tmpMoveKeys[getPressedSetupKeysID()] != e.keyCode) {
			window.alert("You alredy chose this key.\nPlease Choose another...")
			return;
		}
		setupButtton(e.keyCode, getPressedSetupKeysID());
		resetMoveKeysButtons();
	} else {
		keysDown[e.keyCode] = false;
	}
}

function isAButtonPressed() {
	return isButtonPressed["upButton"] || isButtonPressed["downButton"] || isButtonPressed["rightButton"] || isButtonPressed["leftButton"]
}

function getPressedSetupKeysID() {
	if (isButtonPressed["upButton"])
		return "upButton"
	if (isButtonPressed["downButton"])
		return "downButton"
	if (isButtonPressed["rightButton"])
		return "rightButton"
	if (isButtonPressed["leftButton"])
		return "leftButton"
}

function resetMoveKeysButtons() {
	$("#upButton")[0].style.backgroundColor = window.buttonDefaultColor;
	$("#upButton")[0].innerText = "Setup UP Button!";
	$("#downButton")[0].style.backgroundColor = window.buttonDefaultColor;
	$("#downButton")[0].innerText = "Setup DOWN Button!";
	$("#rightButton")[0].style.backgroundColor = window.buttonDefaultColor;
	$("#rightButton")[0].innerText = "Setup RIGHT Button!";
	$("#leftButton")[0].style.backgroundColor = window.buttonDefaultColor;
	$("#leftButton")[0].innerText = "Setup LEFT Button!";
}

function assignMoveKeys() {
	window.moveKeys["upButton"] = window.tmpMoveKeys["upButton"];
	window.moveKeys["rightButton"] = window.tmpMoveKeys["rightButton"];
	window.moveKeys["downButton"] = window.tmpMoveKeys["downButton"];
	window.moveKeys["leftButton"] = window.tmpMoveKeys["leftButton"];
}

function dateOptionReset() {

	//populate our years select box
	for (i = new Date().getFullYear(); i > 1900; i--) {
		$('#years').append($('<option />').val(i).html(i));
	}
	//populate our months select box
	for (i = 1; i < 13; i++) {
		$('#months').append($('<option />').val(i).html(i));
	}
	//populate our Days select box
	updateNumberOfDays();

	//"listen" for change events
	$('#months').change(function () {
		updateNumberOfDays();
	});

}

//function to update the days based on the current values of month and year
function updateNumberOfDays() {
	$('#days').html('');
	month = $('#months').val();
	year = $('#years').val();
	days = daysInMonth(month, year);

	for (i = 1; i < days + 1; i++) {
		$('#days').append($('<option />').val(i).html(i));
	}
}

//get the number of day in a given month
function daysInMonth(month, year) {
	return new Date(year, month, 0).getDate();
}

function createDivsDictionary() {
	window.divsDictionary = {
		"header": $("#header")[0],
		"welcome": $("#welcome")[0],
		"register": $("#register")[0],
		"login": $("#login")[0],
		"setting": $("#setting")[0],
		"game": $("#game")[0],
		"footer": $("#footer")[0]
	}
}

function login() {
	let username = $("#loginUsername")[0].value;
	let password = $("#loginPassword")[0].value;
	if (window.getItem(username) == null || password != window.getItem(username).password) {
		window.alert("Sorry, your username or password is incorrect.\nPlease try again or register");
		return false;
	}
	window.isLogin = true;
	window.goToGame();
	return false;
}

function register() {

	let username = $("#username")[0].value;
	let fullname = $("#fullName")[0].value;
	let email = $("#email")[0].value;
	let password = $("#password")[0].value;
	let repassword = $("#repassword")[0].value;
	let birthdate = new Date($("#years")[0].value, $("#months")[0].value, $("#days")[0].value)

	if (checkRegistrationInfo(username, fullname, password, repassword)) {
		let newUser = {
			userName: username,
			name: fullname,
			email: email,
			password: password,
			birthDate: birthdate
		};
		window.setItem(username, newUser);
		window.alert("The User account was created successfully");
		return true;
	}

	return false;
}

function checkRegistrationInfo(username, fullname, password, repassword) {

	// checks if the user name is not occupied 
	if (username in Object.entries(window.localStorage)) {
		window.alert("This Username already exists...\nPlease Choose another");
		return false;
	}
	if (!username.match(/^[0-9a-zA-Z]+$/)) {
		window.alert("This Username is not valid please use only letters and numbers...");
		return false;
	}
	// check full name
	if (!/^([\w]{3,})+\s+([\w\s]{3,})+$/i.test(fullname) || /\d/.test(fullname)) {
		window.alert("Full Name Field is not valid");
		return false;
	}
	//check password 
	if (password.length < 6 || !/\d/.test(password) || !/[A-Za-z]/.test(password)) {
		window.alert("The password must be at least 6 characters\n and it must contain at least one number and letter");
		return false;
	}
	if (password != repassword) {
		window.alert("The passwords does not match");
		return false;
	}
	return true;
}

function goToWelcomePage() {
	window.hideAllDivs()
	window.divsDictionary.welcome.style.display = "block";
}

function goToRegisterPage() {
	window.hideAllDivs()
	window.divsDictionary.register.style.display = "block";
	window.divsDictionary.header.style.display = "block";
	window.divsDictionary.footer.style.display = "block";
}

function goToLoginPage() {
	window.hideAllDivs()
	window.divsDictionary.login.style.display = "block";
	window.divsDictionary.header.style.display = "block";
	window.divsDictionary.footer.style.display = "block";
}

function goToSettings() {
	window.hideAllDivs()
	window.divsDictionary.setting.style.display = "block";
	window.divsDictionary.header.style.display = "block";
	window.divsDictionary.footer.style.display = "block";
}

function goToGame() {
	window.hideAllDivs()
	window.divsDictionary.game.style.display = "block";
	window.divsDictionary.header.style.display = "block";
	window.divsDictionary.footer.style.display = "block";
}

function loginAlert() {
	window.alert("Please Login First...")
}

function hideAllDivs() {
	Object.values(window.divsDictionary).forEach(element => {
		element.style.display = "none";
	});
}

function resetUsersDictionary() {
	let deafultUser = {
		userName: "p",
		name: "p",
		email: "p",
		password: "p",
		birthDate: new Date(2000, 1, 1)
	};
	window.setItem("p", deafultUser);
}

function setItem(username, user) {
	window.localStorage.setItem(username, JSON.stringify(user));
}

function getItem(username) {
	return JSON.parse(window.localStorage.getItem(username));
}


